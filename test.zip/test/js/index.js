let utils = new Utils('errorMessage');
let stats = null;
// let controls = {};
let videoConstraint = {
  facingMode: { exact: "environment" },
};
let streaming = false;
let videoTrack = null;
let video = document.getElementById('videoInput');
let canvasOutput = document.getElementById('canvasOutput');
let canvasResult = document.getElementById('canvasResult');
let canvasInput = null;
let canvasInputCtx = null;
let src = null;
let dst = null;

let play = true;

const debug = 2;

let holdCount = 0;

let toleranceX = 60;
let toleranceY = 150;

let inFocus = false;
let captured = false;
let focusTopLeftPoints = {};
let focusBottomRightPoints = {};

if (isMobileDevice()) {
  toleranceX = toleranceX / 2;
  toleranceY = toleranceY / 2;
}

let controls = {
  // We draw rectangle on video stream to position card inside it
  // so expected contour includes vertices of this rectangle.
  expectedContour: [],
  rectColor: [255, 255, 255, 255], // White color.

};

const moveInstructions = document.getElementById('move');


function initOpencvObjects() {
  src = new cv.Mat(video.height, video.width, cv.CV_8UC4);
  dst = new cv.Mat();
}

function completeStyling() {

  let mainContent = document.getElementById('mainContent');


  document.querySelector('.canvas-wrapper').style.height =
    `${video.videoHeight}px`;

  calculateRectCoordinates();

  // Extra canvas to get source image from video element
  // (instead of cv.VideoCapture).
  canvasInput = document.createElement('canvas');
  canvasInput.width = video.width;
  canvasInput.height = video.height;
  canvasInputCtx = canvasInput.getContext('2d');

  mainContent.classList.remove('hidden');
}

function processVideo() {
  const begin = Date.now();
  try {
    if (!streaming) {
      cleanupAndStop();
      return;
    }
    canvasInputCtx.drawImage(video, 0, 0, video.width, video.height);
    let imageData = canvasInputCtx.getImageData(0, 0, video.width, video.height);
    src.data.set(imageData.data);
    
    detect('canvasOutput', src);

    const FPS = 30;
    const delay = 1000/FPS - (Date.now() - begin);
    if(play) {
      setTimeout(processVideo, delay);
    }

  } catch (err) {
    utils.printError(err);
  }
}

function detect(source, src) {
  let cv = this.cv
  const img = cv.imread(source)
  const gray = new cv.Mat();
  cv.cvtColor(src, gray, cv.COLOR_RGBA2GRAY);
  const blur = new cv.Mat();
  cv.GaussianBlur(gray, blur, new cv.Size(5, 5), 0, 0, cv.BORDER_DEFAULT)
  cv.Canny(blur, blur, 50, 150);
  const thresh = new cv.Mat();
  cv.threshold(blur, thresh, 0, 255, cv.THRESH_BINARY + cv.THRESH_OTSU)
  cv.imshow('canvasOutput', blur);
  
  let contours = new cv.MatVector();
  let hierarchy = new cv.Mat();

    cv.findContours(
      thresh,
      contours,
      hierarchy,
      cv.RETR_CCOMP,
      cv.CHAIN_APPROX_SIMPLE
    );

    let points = [];

    if (contours.size()) {
      let maxArea = 1000
      let maxContourIndex = -1
      for (let i = 0; i < contours.size(); ++i) {
        let contourArea = cv.contourArea(contours.get(i));

        //console.log(cv.contourArea(contours.get(i)));
        //console.log(contourArea > maxArea);

/*         let indexSort = Array.from(Array(contours.size()).keys())
        .sort((a, b) => cv.contourArea(contours.get(b)) - cv.contourArea(contours.get(a)));

        let cnt = contours.get(indexSort[i]);
        let peri = cv.arcLength(cnt, true);
	      let approx = new cv.Mat();
	      cv.approxPolyDP(cnt, approx, 0.02 * peri, true); // Adjusted approximation factor for better accuracy

        if (contourArea > maxArea && 
          approx.rows === 4 && hierarchy.data32S[indexSort[i] * 4 + 3] === -1) { */
        if (contourArea > maxArea) {
          //maxArea = contourArea
          maxContourIndex = i
        }
      }

      if (maxContourIndex >= 0) {
        const maxContour = contours.get(maxContourIndex);
        const maxContourArea = cv.contourArea(maxContour);
        if (maxContourArea > maxArea) {
          points = this.getCornerPoints(maxContour);
        }
      }

    }

    if (debug > 2) {
      const colour = new cv.Mat();
      cv.cvtColor(thresh, colour, cv.COLOR_GRAY2RGBA);
      //src = colour.clone();
      colour.copyTo(src);
      colour.delete();
    }

    img.delete();
    gray.delete();
    blur.delete();
    thresh.delete();
    contours.delete();
    hierarchy.delete();

    const padding = 15;

    cv.rectangle(src, { x: controls.expectedContour[0].x - padding, y: controls.expectedContour[0].y - padding }, { x: controls.expectedContour[2].x + padding, y: controls.expectedContour[2].y + padding }, controls.rectColor, 2);

    if (debug > 0) {
      const colorDebugBlue = [0, 0, 255, 255]; // blue
      cv.rectangle(src, {x: controls.expectedContour[0].x + toleranceX, y: controls.expectedContour[0].y + toleranceY}, {x: controls.expectedContour[2].x - toleranceX, y: controls.expectedContour[2].y - toleranceY}, colorDebugBlue, 2);
    }

    if (inFocus) {
      if (debug > 0) {
        const color = [0, 255, 0, 255]; // Green
        cv.rectangle(src, focusTopLeftPoints, focusBottomRightPoints, color, 2);
      }

      holdCount = ++holdCount;
      const holdTotal = (holdCount / 30).toFixed(0);
      moveInstructions.innerText = `Hold still ${holdTotal}`;
      if (holdTotal == 4) {
        //play = false;
        //grab the context from your destination canvas
        moveInstructions.innerText = `Image captured`;
        const destCtx = canvasResult.getContext('2d');    
        //call its drawImage() function passing it the source canvas directly
        canvasOutput.classList.add("hidden");
        canvasResult.classList.remove('hidden');
        canvasResult.width = video.width;
        canvasResult.height = video.height;
        destCtx.drawImage(video, 0, 0, video.width, video.height);
        inFocus = false;
        captured = true;
        cleanupAndStop();
      }
    }

    if (points[0] && points[2] && !inFocus) {
      const topLeftPoints = { x: points[0].x - padding, y: points[0].y - padding };
      const bottomRightPoints = { x: points[2].x + padding, y: points[2].y + padding };
      const inRange = isWithinRange(topLeftPoints, bottomRightPoints);
      if (debug > 1 && !inRange) {
        const colorDebugRed = [255, 0, 0, 255]; // red
        cv.rectangle(src, topLeftPoints, bottomRightPoints, colorDebugRed, 2);
      }
      if (inRange && !inFocus) {
        //const color = [0, 255, 0, 255]; // Green
        //cv.rectangle(src, topLeftPoints, bottomRightPoints, color, 2);
        inFocus = true;
        focusTopLeftPoints = topLeftPoints;
        focusBottomRightPoints = bottomRightPoints;
      }
    }
    cv.imshow('canvasOutput', src);
    points = [];
}

function isWithinRange(topLeftCorner, bottomRightCorner) {
  const topLeftXGreater = topLeftCorner.x > controls.expectedContour[0].x;
  const topLeftYGreater = topLeftCorner.y > controls.expectedContour[0].y;
  const bottomRightXLesser = bottomRightCorner.x < controls.expectedContour[2].x;
  const bottomRightYLesser = bottomRightCorner.y < controls.expectedContour[2].y;

  const topLeftXLesser = topLeftCorner.x < (controls.expectedContour[0].x + toleranceX);
  const topLeftYLesser = topLeftCorner.y < (controls.expectedContour[0].y + toleranceY);
  const bottomRightXGreater = bottomRightCorner.x > (controls.expectedContour[2].x - toleranceX);
  const bottomRightYGreater = bottomRightCorner.y > (controls.expectedContour[2].y - toleranceY);

  const minWidth = (bottomRightCorner.x - topLeftCorner.x) > ((controls.expectedContour[2].x - toleranceX) - (controls.expectedContour[0].x + toleranceX));
  const minHeight = (bottomRightCorner.y - topLeftCorner.y) > ((controls.expectedContour[2].y - toleranceY) - (controls.expectedContour[0].y + toleranceY));

  const minWidthThreshold = (bottomRightCorner.x - topLeftCorner.x) + 100 > ((controls.expectedContour[2].x - toleranceX) - (controls.expectedContour[0].x + toleranceX));
  const minHeightThreshold = (bottomRightCorner.y - topLeftCorner.y) + 100 > ((controls.expectedContour[2].y - toleranceY) - (controls.expectedContour[0].y + toleranceY));

  const tooSmall = !minWidth || !minHeight;

  const total = topLeftXGreater + topLeftYGreater + bottomRightXLesser + bottomRightYLesser + topLeftXLesser + topLeftYLesser + bottomRightXGreater + bottomRightYGreater + !tooSmall;

  const moveRight = (topLeftXGreater && !bottomRightXLesser) || (!topLeftXLesser && bottomRightXGreater);
  const moveLeft = (!topLeftXGreater && bottomRightXLesser) || (topLeftXLesser && !bottomRightXGreater);
  const moveUp = (!topLeftYGreater && bottomRightYLesser) || (topLeftYLesser && !bottomRightYGreater);
  const moveDown = (topLeftYGreater && !bottomRightYLesser) || (!topLeftYLesser && bottomRightYGreater);

  if (topLeftXGreater && topLeftYGreater && bottomRightXLesser && bottomRightYLesser && minWidthThreshold && minHeightThreshold && !captured) {
    showDynamicInstruction(moveRight, moveLeft, moveUp, moveDown, total, tooSmall);
  } else {
    if (!captured) {
      moveInstructions.innerText = `Position document inside the rectangle`;
    }
    // holdCount = 0;
  }

  return total === 9 ? true : false;
}



function showDynamicInstruction(moveRight, moveLeft, moveUp, moveDown, total, tooSmall) {

  let text = '';

  if (total < 9 || !inFocus) {
    // holdCount = 0;
    let position = `${moveRight && !moveLeft ? 'right ' : ''}${moveLeft && !moveRight  ? 'left ' : ''}${moveUp && !moveDown  ? 'up ' : ''}${moveDown && !moveUp  ? 'down ' : ''}${tooSmall  ? 'closer ' : ''}`;
    if (position) {
      text = `Move ${position}`;
    } else {
      text = `Position document inside the rectangle`;
    }

  } else {
    /* holdCount = ++holdCount;
    const holdTotal = (holdCount / 30).toFixed(0);
    text = `Hold still ${holdTotal}`;
    if (holdTotal == 4) {
      //play = false;
      //grab the context from your destination canvas
      const destCtx = canvasResult.getContext('2d');    
      //call its drawImage() function passing it the source canvas directly
      destCtx.drawImage(src, 0, 0);
      canvasResult.classList.remove('hidden');
    } */
  }

  moveInstructions.innerText !== text ? moveInstructions.innerText = text : null;
}

function getCornerPoints(contour) {
  let cv = this.cv
  let points = []
  let rect = cv.minAreaRect(contour)
  const center = rect.center

  let topLeftPoint
  let topLeftDistance = 0

  let topRightPoint
  let topRightDistance = 0

  let bottomLeftPoint
  let bottomLeftDistance = 0

  let bottomRightPoint
  let bottomRightDistance = 0

  for (let i = 0; i < contour.data32S.length; i += 2) {
    const point = { x: contour.data32S[i], y: contour.data32S[i + 1] }
    const distance = this.distance(point, center)
    if (point.x < center.x && point.y < center.y) {
      if (distance > topLeftDistance) {
        topLeftPoint = point
        topLeftDistance = distance
      }
    } else if (point.x > center.x && point.y < center.y) {
      if (distance > topRightDistance) {
        topRightPoint = point
        topRightDistance = distance
      }
    } else if (point.x < center.x && point.y > center.y) {
      if (distance > bottomLeftDistance) {
        bottomLeftPoint = point
        bottomLeftDistance = distance
      }
    } else if (point.x > center.x && point.y > center.y) {
      if (distance > bottomRightDistance) {
        bottomRightPoint = point
        bottomRightDistance = distance
      }
    }
  }
  points.push(topLeftPoint)
  points.push(topRightPoint)
  points.push(bottomRightPoint)
  points.push(bottomLeftPoint)
  return points
}

function distance(p1, p2) {
  return Math.hypot(p1.x - p2.x, p1.y - p2.y)
}

function calculateRectCoordinates() {

  if (isMobileDevice()) {
    const rectRatio = 1.586;
    let xLeft = parseInt(video.width * 0.1);
    let xRight = parseInt(video.width * 0.9);
    let width = xRight - xLeft;
    let height = width / rectRatio + 200;
    let yUpper = parseInt(video.height / 2 - height / 2);
    let yBottom = parseInt(yUpper + height);
    controls.expectedContour.push({ x: xLeft, y: yUpper });
    controls.expectedContour.push({ x: xRight, y: yUpper });
    controls.expectedContour.push({ x: xRight, y: yBottom });
    controls.expectedContour.push({ x: xLeft, y: yBottom });
  } else {
    const rectRatio = 1.586;
    let xLeft = parseInt(video.width * 0.35);
    let xRight = parseInt(video.width * 0.75);
    let width = xRight - xLeft;
    let height = width / rectRatio + 300;
    let yUpper = parseInt(video.height / 2 - height / 2);
    let yBottom = parseInt(yUpper + height);
    controls.expectedContour.push({ x: xLeft, y: yUpper });
    controls.expectedContour.push({ x: xRight, y: yUpper });
    controls.expectedContour.push({ x: xRight, y: yBottom });
    controls.expectedContour.push({ x: xLeft, y: yBottom });

  }

}

function startCamera() {
  utils.startCamera(videoConstraint, 'videoInput', onVideoStarted);
}

function cleanupAndStop() {
  //src.delete(); dst.delete();
  utils.stopCamera(); onVideoStopped();
}

utils.loadOpenCv(() => {
  getVideoConstraint(50);
  initCameraSettingsAndStart();
});
